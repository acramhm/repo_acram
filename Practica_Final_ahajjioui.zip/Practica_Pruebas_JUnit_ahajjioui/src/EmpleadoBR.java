
public class EmpleadoBR {
	
	private int tipo; 
	private float ventasMes;
	private float horasExtra;
	private float salarioBruto;
	
	EmpleadoBR(){}
	
	EmpleadoBR(int tipo, float ventasMes, float horasExtra){
		this.tipo = tipo;
		this.ventasMes = ventasMes;
		this.horasExtra = horasExtra;
	}
	
	EmpleadoBR(float salarioBruto){
		this.salarioBruto = salarioBruto;
	}
	
	public float calculaSalarioBruto() {
		float salarioBruto = 0;
		
		if (tipo == 0) {
			salarioBruto = 1000 + (20 * horasExtra);
			if (ventasMes >= 1500) {
				salarioBruto = salarioBruto + 200;
			} else if (ventasMes >= 1000) {
				salarioBruto = salarioBruto + 100;
			}
		} else if (tipo == 1) {
			salarioBruto = 1500 + (20 * horasExtra);;
			if (ventasMes >= 1500) {
				salarioBruto = salarioBruto + 200;
			} else if (ventasMes >= 1000) {
				salarioBruto = salarioBruto + 100;
			}
		}
		
		return salarioBruto;
		
	}
	
	public float calculaSalarioNeto() {
		
		if (salarioBruto >= 1000 && salarioBruto < 1500) {
			salarioBruto = (float) (salarioBruto - (salarioBruto * 0.16));
		} else if (salarioBruto >= 1500) {
			salarioBruto = (float) (salarioBruto - (salarioBruto * 0.18));
		}
		
		return salarioBruto;
		
	}
	
}
