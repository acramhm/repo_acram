import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class JUnitSalaris {

	private EmpleadoBR c;
	
	@Test 
	public void proba1() {
		float sortidaEsperada = 1640;
		c = new EmpleadoBR(2000);
		assertEquals(sortidaEsperada, c.calculaSalarioNeto(), 0);
	}
	@Test 
	public void proba2() {
		float sortidaEsperada = 1230;
		c = new EmpleadoBR(1500);
		assertEquals(sortidaEsperada, c.calculaSalarioNeto(), 0);
	}
	@Test 
	public void proba3() {
		float sortidaEsperada = 1259.9916f;
		c = new EmpleadoBR(1499.99f);
		assertEquals(sortidaEsperada, c.calculaSalarioNeto(), 0);
	}
	@Test 
	public void proba4() {
		float sortidaEsperada = 1050;
		c = new EmpleadoBR(1250);
		assertEquals(sortidaEsperada, c.calculaSalarioNeto(), 0);
	}
	@Test 
	public void proba5() {
		float sortidaEsperada = 840;
		c = new EmpleadoBR(1000);
		assertEquals(sortidaEsperada, c.calculaSalarioNeto(), 0);
	}
	@Test 
	public void proba6() {
		float sortidaEsperada = 999.99f;
		c = new EmpleadoBR(999.99f);
		assertEquals(sortidaEsperada, c.calculaSalarioNeto(), 0);
	}
	@Test 
	public void proba7() {
		float sortidaEsperada = 500;
		c = new EmpleadoBR(500);
		assertEquals(sortidaEsperada, c.calculaSalarioNeto(), 0);
	}
	@Test 
	public void proba8() {
		float sortidaEsperada = 0;
		c = new EmpleadoBR(0);
		assertEquals(sortidaEsperada, c.calculaSalarioNeto(), 0);
	}
	@Test 
	public void proba9() {
		float sortidaEsperada = 1360;
		c = new EmpleadoBR(0,2000,8);
		assertEquals(sortidaEsperada, c.calculaSalarioBruto(), 0);
	}
	@Test 
	public void proba10() {
		float sortidaEsperada = 1260;
		c = new EmpleadoBR(0,1500,3);
		assertEquals(sortidaEsperada, c.calculaSalarioBruto(), 0);
	}
	@Test 
	public void proba11() {
		float sortidaEsperada = 1100;
		c = new EmpleadoBR(0,1499.99f,0);
		assertEquals(sortidaEsperada, c.calculaSalarioBruto(), 0);
	}
	@Test 
	public void proba12() {
		float sortidaEsperada = 1760;
		c = new EmpleadoBR(1,1250,8);
		assertEquals(sortidaEsperada, c.calculaSalarioBruto(), 0);
	}
	@Test 
	public void proba13() {
		float sortidaEsperada = 1600;
		c = new EmpleadoBR(1,1000,0);
		assertEquals(sortidaEsperada, c.calculaSalarioBruto(), 0);
	}
	@Test 
	public void proba14() {
		float sortidaEsperada = 1560;
		c = new EmpleadoBR(1,999.99f,3);
		assertEquals(sortidaEsperada, c.calculaSalarioBruto(), 0);
	}
	@Test 
	public void proba15() {
		float sortidaEsperada = 1500;
		c = new EmpleadoBR(1,500,0);
		assertEquals(sortidaEsperada, c.calculaSalarioBruto(), 0);
	}
	@Test 
	public void proba16() {
		float sortidaEsperada = 1660;
		c = new EmpleadoBR(1,0,8);
		assertEquals(sortidaEsperada, c.calculaSalarioBruto(), 0);
	}
}
